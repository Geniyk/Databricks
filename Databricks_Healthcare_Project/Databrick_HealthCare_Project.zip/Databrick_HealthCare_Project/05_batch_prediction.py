# Databricks notebook source
import os
import mlflow
import mlflow.spark

# Required for shared / serverless clusters
os.environ["MLFLOW_DFS_TMP"] = "/Volumes/healthcare/gold/mlflow_tmp"

# Set experiment 
mlflow.set_experiment(
    "/Users/saurabhkrchauhan1402@gmail.com/healthcare_readmission"
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### LOAD GOLD FEATURE DATA

# COMMAND ----------

df_gold = spark.read.table(
    "healthcare.gold.readmission_features"
)


# COMMAND ----------

df_gold.printSchema()
df_gold.show(5)


# COMMAND ----------

train_df, test_df = df_gold.randomSplit([0.8, 0.2], seed=42)

print("Train count:", train_df.count())
print("Test count:", test_df.count())


# COMMAND ----------

from pyspark.ml.classification import LogisticRegression

lr = LogisticRegression(
    featuresCol="features",
    labelCol="readmitted_flag",
    maxIter=50
)

lr_model = lr.fit(train_df)

print("Model trained successfully")


# COMMAND ----------

# MAGIC %md
# MAGIC ### EVALUATE MODEL

# COMMAND ----------

from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.evaluation import MulticlassClassificationEvaluator

preds = lr_model.transform(test_df)

auc = BinaryClassificationEvaluator(
    labelCol="readmitted_flag",
    metricName="areaUnderROC"
).evaluate(preds)

accuracy = MulticlassClassificationEvaluator(
    labelCol="readmitted_flag",
    predictionCol="prediction",
    metricName="accuracy"
).evaluate(preds)

print("AUC:", auc)
print("Accuracy:", accuracy)


# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG MODEL TO MLFLOW

# COMMAND ----------

with mlflow.start_run():

    mlflow.log_param("model_type", "LogisticRegression")
    mlflow.log_metric("AUC", auc)
    mlflow.log_metric("Accuracy", accuracy)

    mlflow.spark.log_model(
        lr_model,
        artifact_path="model"
    )

    run_id = mlflow.active_run().info.run_id
    print("MLflow run_id:", run_id)


# COMMAND ----------

model_uri = f"runs:/{run_id}/model"

loaded_model = mlflow.spark.load_model(model_uri)

print("Model loaded successfully from MLflow")


# COMMAND ----------

# MAGIC %md
# MAGIC ### BATCH PREDICTIONS

# COMMAND ----------

df_predictions = loaded_model.transform(df_gold)

df_predictions.select(
    "readmitted_flag",
    "prediction",
    "probability"
).show(10, truncate=False)


# COMMAND ----------

# MAGIC %md
# MAGIC ### SAVE PREDICTIONS TO GOLD

# COMMAND ----------

from pyspark.ml.functions import vector_to_array
from pyspark.sql.functions import col

df_final = (
    df_predictions
    .withColumn(
        "readmission_risk_score",
        vector_to_array(col("probability"))[1]
    )
    .select(
        "readmitted_flag",
        "prediction",
        "readmission_risk_score"
    )
)


# COMMAND ----------

(
    df_final.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("healthcare.gold.readmission_predictions")
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### SQL CHECK

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM healthcare.gold.readmission_predictions
# MAGIC LIMIT 10;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS total_rows
# MAGIC FROM healthcare.gold.readmission_predictions;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES IN healthcare.gold;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### DATA QUALITY CHECK

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   COUNT(*) AS total,
# MAGIC   SUM(prediction) AS predicted_readmissions,
# MAGIC   AVG(readmission_risk_score) AS avg_risk
# MAGIC FROM healthcare.gold.readmission_predictions;
# MAGIC

# COMMAND ----------

