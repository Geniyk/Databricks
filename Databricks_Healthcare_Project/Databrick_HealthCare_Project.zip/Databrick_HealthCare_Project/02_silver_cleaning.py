# Databricks notebook source
df_bronze = spark.read.table("healthcare.bronze.train_df")


# COMMAND ----------

df_bronze.printSchema()
df_bronze.show(5)


# COMMAND ----------

df_silver = df_bronze.fillna({
    "gender": "Unknown",
    "primary_diagnosis": "Unknown",
    "discharge_to": "Unknown"
})


# COMMAND ----------

display(df_silver)


# COMMAND ----------

df_silver = df_silver.withColumnRenamed(
    "readmitted", "readmitted_flag"
)
display(df_silver)



# COMMAND ----------

from pyspark.sql.functions import col

df_silver = (
    df_silver
    .withColumn("long_stay", col("days_in_hospital") >= 7)
    .withColumn("high_comorbidity", col("comorbidity_score") >= 3)
    .withColumn("many_procedures", col("num_procedures") >= 5)
)


# COMMAND ----------

df_silver.columns


# COMMAND ----------

silver_cols = [
    "age",
    "gender",
    "primary_diagnosis",
    "num_procedures",
    "days_in_hospital",
    "comorbidity_score",
    "discharge_to",
    "long_stay",
    "high_comorbidity",
    "many_procedures",
    "readmitted_flag"
]

df_silver = df_silver.select(silver_cols)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Write SILVER Table

# COMMAND ----------

(
    df_silver.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("healthcare.silver.readmission_clean")
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### VERIFY SILVER

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM healthcare.silver.readmission_clean LIMIT 10;
# MAGIC

# COMMAND ----------

