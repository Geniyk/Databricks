# Databricks notebook source
df_gold = spark.read.table(
    "healthcare.gold.readmission_features"
)


# COMMAND ----------

df_gold.printSchema()
df_gold.show(5)


# COMMAND ----------

train_df, test_df = df_gold.randomSplit(
    [0.8, 0.2],
    seed=42
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### MODEL (LOGISTIC REGRESSION)
# MAGIC
# MAGIC Why Logistic Regression?
# MAGIC
# MAGIC - Interpretable (important in healthcare)
# MAGIC
# MAGIC - Baseline benchmark
# MAGIC
# MAGIC - Fast & stable

# COMMAND ----------

from pyspark.ml.classification import LogisticRegression

lr = LogisticRegression(
    featuresCol="features",
    labelCol="readmitted_flag",
    maxIter=50
)

lr_model = lr.fit(train_df)


# COMMAND ----------

predictions = lr_model.transform(test_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### MODEL EVALUATION

# COMMAND ----------

from pyspark.ml.evaluation import BinaryClassificationEvaluator

evaluator = BinaryClassificationEvaluator(
    labelCol="readmitted_flag",
    metricName="areaUnderROC"
)

auc = evaluator.evaluate(predictions)
print("Test AUC:", auc)


# COMMAND ----------

from pyspark.ml.evaluation import MulticlassClassificationEvaluator

accuracy_eval = MulticlassClassificationEvaluator(
    labelCol="readmitted_flag",
    predictionCol="prediction",
    metricName="accuracy"
)

accuracy = accuracy_eval.evaluate(predictions)
print("Accuracy:", accuracy)


# COMMAND ----------

# MAGIC %md
# MAGIC ### MLFLOW TRACKING

# COMMAND ----------

import mlflow
import mlflow.spark

experiment_path = "/Users/saurabhkrchauhan1402@gmail.com/healthcare_readmission"

mlflow.set_experiment(experiment_path)


# COMMAND ----------

# MAGIC %md
# MAGIC ### UC VOLUME

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VOLUME IF NOT EXISTS healthcare.gold.mlflow_tmp;
# MAGIC

# COMMAND ----------

import os

os.environ["MLFLOW_DFS_TMP"] = "/Volumes/healthcare/gold/mlflow_tmp"


# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG MODEL, METRICS & PARAMS

# COMMAND ----------

import os
import mlflow
import mlflow.spark

# REQUIRED for Databricks shared/serverless clusters
os.environ["MLFLOW_DFS_TMP"] = "/Volumes/healthcare/gold/mlflow_tmp"

# Set MLflow experiment
experiment_path = "/Users/saurabhkrchauhan1402@gmail.com/healthcare_readmission"
mlflow.set_experiment(experiment_path)

with mlflow.start_run():

    # Log model parameters
    mlflow.log_param("model_type", "LogisticRegression")
    mlflow.log_param("max_iter", lr_model.getMaxIter())
    mlflow.log_param("elastic_net_param", lr_model.getElasticNetParam())
    mlflow.log_param("reg_param", lr_model.getRegParam())

    # Log evaluation metrics
    mlflow.log_metric("AUC", auc)
    mlflow.log_metric("Accuracy", accuracy)

    # Log Spark ML model
    mlflow.spark.log_model(
        lr_model,
        artifact_path="readmission_model"
    )


# COMMAND ----------

