# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE CATALOG IF NOT EXISTS healthcare;
# MAGIC USE CATALOG healthcare;
# MAGIC
# MAGIC CREATE SCHEMA IF NOT EXISTS bronze;
# MAGIC CREATE SCHEMA IF NOT EXISTS silver;
# MAGIC CREATE SCHEMA IF NOT EXISTS gold;
# MAGIC

# COMMAND ----------

df_bronze = spark.read.table("healthcare.bronze.train_df")


# COMMAND ----------

display(df_bronze)

# COMMAND ----------

df_bronze.printSchema()
df_bronze.show(5)


# COMMAND ----------

