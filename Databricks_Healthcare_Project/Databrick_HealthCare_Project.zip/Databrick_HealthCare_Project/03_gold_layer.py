# Databricks notebook source
df_silver = spark.read.table(
    "healthcare.silver.readmission_clean"
)


# COMMAND ----------

from pyspark.ml.feature import StringIndexer

gender_indexer = StringIndexer(
    inputCol="gender",
    outputCol="gender_index",
    handleInvalid="keep"
)

diagnosis_indexer = StringIndexer(
    inputCol="primary_diagnosis",
    outputCol="diagnosis_index",
    handleInvalid="keep"
)

discharge_indexer = StringIndexer(
    inputCol="discharge_to",
    outputCol="discharge_index",
    handleInvalid="keep"
)


# COMMAND ----------

df_gold = gender_indexer.fit(df_silver).transform(df_silver)
df_gold = diagnosis_indexer.fit(df_gold).transform(df_gold)
df_gold = discharge_indexer.fit(df_gold).transform(df_gold)


# COMMAND ----------

# MAGIC %md
# MAGIC ### FEATURE VECTOR ASSEMBLY (Define Feature Columns)

# COMMAND ----------

feature_cols = [
    "age",
    "num_procedures",
    "days_in_hospital",
    "comorbidity_score",
    "long_stay",
    "high_comorbidity",
    "many_procedures",
    "gender_index",
    "diagnosis_index",
    "discharge_index"
]


# COMMAND ----------

# MAGIC %md
# MAGIC ### VectorAssembler

# COMMAND ----------

from pyspark.ml.feature import VectorAssembler

assembler = VectorAssembler(
    inputCols=feature_cols,
    outputCol="features"
)

df_gold = assembler.transform(df_gold)


# COMMAND ----------

# MAGIC %md
# MAGIC ### FINAL GOLD ML FEATURE TABLE

# COMMAND ----------

df_gold_final = df_gold.select(
    "features",
    "readmitted_flag"
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### WRITE GOLD ML TABLE

# COMMAND ----------

(
    df_gold_final.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable(
        "healthcare.gold.readmission_features"
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### VERIFY GOLD FEATURE TABLE

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM healthcare.gold.readmission_features
# MAGIC LIMIT 5;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read Silver Again

# COMMAND ----------

df = spark.read.table(
    "healthcare.silver.readmission_clean"
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Aggregate

# COMMAND ----------

from pyspark.sql.functions import avg

df_summary = (
    df.groupBy("discharge_to")
      .agg(avg("readmitted_flag")
           .alias("readmission_rate"))
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Write Aggregate Table

# COMMAND ----------

(
    df_summary.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable(
        "healthcare.gold.readmission_summary"
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### VERIFY BUSINESS TABLE

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM healthcare.gold.readmission_summary;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES IN healthcare.gold;
# MAGIC

# COMMAND ----------

